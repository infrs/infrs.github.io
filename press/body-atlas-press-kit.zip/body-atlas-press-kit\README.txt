Body Atlas: Train & Nutrition - press kit
==========================================

Free Android app by infrs (one developer).
Google Play: https://play.google.com/store/apps/details?id=com.infrs.bodyatlas
Website and press page: https://infrs.github.io/press.html
Contact: temporaldreams0@gmail.com

ONE LINE
Tap any muscle or organ on a 3D body to see the best exercises for it and the foods that feed it. Free, no account.

SHORT DESCRIPTION
Body Atlas turns a 3D model of the human body into a guide to training and nutrition. Tap a muscle to get exercises for it, with start and end pictures and the helper muscles each move works. Tap an organ or bone to see the nutrients it relies on and the foods richest in them. It also has a training plan maker and a journal for workouts, cardio, food and water. Every feature is free, there's no account, and everything is stored on the phone.

FACTS
- Platform: Android (Google Play). iOS planned.
- Price: free. Optional rewarded videos unlock themes; optional supporter badges.
- 1,200+ exercises, 85 named muscles, hundreds of everyday foods (USDA FoodData Central)
- 7 languages: English, Arabic, Spanish, Portuguese, French, German, Japanese
- No account, no sign-up, works offline
- Launched November 2026

IN THIS FOLDER
screenshots/  Phone screenshots, 1080 x 1920 (English)
3d-body/      Stills of the 3D body, 1080 x 1920
brand/        App icon (512 x 512) and Play feature graphic (1024 x 500)

VIDEOS (download from the press page)
https://infrs.github.io/press/video/body-atlas-promo-20s.mp4
https://infrs.github.io/press/video/body-atlas-3d-body.mp4

You're welcome to use any of these images and videos in articles, reviews and videos about the app.
